class CountrySerializer < ActiveModel::Serializer

	attributes :id,
	:name

end  