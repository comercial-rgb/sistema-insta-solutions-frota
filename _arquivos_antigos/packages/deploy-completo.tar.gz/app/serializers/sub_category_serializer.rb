class SubCategorySerializer < ActiveModel::Serializer
	
	attributes :id,
	:name,
	:subcategory_id

end
