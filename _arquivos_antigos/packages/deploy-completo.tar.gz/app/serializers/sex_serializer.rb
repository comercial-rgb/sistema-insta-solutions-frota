class SexSerializer < ActiveModel::Serializer

	attributes :id,
	:name

end  