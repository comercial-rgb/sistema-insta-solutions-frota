class PersonTypeSerializer < ActiveModel::Serializer

	attributes :id,
	:name

end  