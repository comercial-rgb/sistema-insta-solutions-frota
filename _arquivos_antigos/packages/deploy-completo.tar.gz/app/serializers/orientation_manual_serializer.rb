class OrientationManualSerializer < ActiveModel::Serializer
  attributes :id, :name, :description
end
