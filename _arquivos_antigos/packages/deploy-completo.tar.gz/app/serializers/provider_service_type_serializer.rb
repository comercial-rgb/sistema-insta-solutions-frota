class ProviderServiceTypeSerializer < ActiveModel::Serializer
  attributes :id, :name, :description
end
