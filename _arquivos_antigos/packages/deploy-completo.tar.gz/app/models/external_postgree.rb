class ExternalPostgree < ActiveRecord::Base

	# TABLE_NAME = '{NOME_DA_TABELA}'

	# remove_connection(self)
	# ActiveRecord::Base.establish_connection(:integration)

	# self.table_name = TABLE_NAME
end