$(document).ready(function(){

    $('.checkbox-select').multipleSelect({
        width: '100%',
        selectAllText: 'TODOS',
        allSelected: 'Todos'
    });

});
