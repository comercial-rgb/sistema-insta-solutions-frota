$(document).ready(() => {

	//// Apresentar a localização geográfica atual do usuário (latitude e longitude)
	// getLocation();
	// function getLocation() {
	//   if (navigator.geolocation) {
	//     navigator.geolocation.getCurrentPosition(showPosition);
	//   } else {
	//     console.log("Geolocation is not supported by this browser.");
	//   }
	// }

	// function showPosition(position) {
	//   console.log("Lat: "+position.coords.latitude+" / Lng: "+position.coords.longitude);
	// }
});