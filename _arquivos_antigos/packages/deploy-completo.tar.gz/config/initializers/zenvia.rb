# require 'zenvia'

# Zenvia.configure do |config|
#   config.account  = ''
#   config.code     = ''
#   config.dispatch = 'send'
#   config.from     = 'Insta Solutions'
# end