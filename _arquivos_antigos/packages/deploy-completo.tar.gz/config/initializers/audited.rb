Audited.current_user_method = :current_user
