module ContractsHelper
end
