class AddressType < ApplicationRecord
end
