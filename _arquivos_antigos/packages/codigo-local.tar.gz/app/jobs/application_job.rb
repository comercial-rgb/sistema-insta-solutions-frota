class ApplicationJob < ActiveJob::Base
end
