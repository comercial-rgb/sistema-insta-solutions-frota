class SiteContactSubjectSerializer < ActiveModel::Serializer

  attributes :id,
  :name

end  
