class AddressTypeSerializer < ActiveModel::Serializer

	attributes :id,
	:name

end  